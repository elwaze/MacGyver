# MacGyver

## OpenClassrooms : 3rd project : create a maze with pygame 

The aim of this project was to create a game where the player has to move Mac Giver through a maze with the cursor keys.  
Before trying to escape, he has to collect 3 objects on his way.

Python script.  
files : main.py, items.py, maze.py, cons.py, maze.txt, images, font

## How to play :

To start playing, open the mac_gyver.exe file.
Then you can move Mac Gyver by using the cursor keys. 
You have to go through the maze, pick the ether bottle, the needle and the plastic pipe to make a syringe to asleep the guard with ether.
Once the syringe is assembled, you can go to see the guard and asleep him to escape.


